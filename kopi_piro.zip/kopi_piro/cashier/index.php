<?php
require_once __DIR__.'/../functions.php';require_cashier();
if(is_owner()){header('Location: ../owner/index.php');exit;}
header('Location: orders.php');exit;
