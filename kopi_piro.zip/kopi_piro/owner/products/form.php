<?php
require_once __DIR__.'/../../functions.php';require_owner();
$id=(int)($_GET['id']??0);$p=['name'=>'','description'=>'','category'=>'coffee','price'=>'','image'=>null];$error='';
if($id){$s=mysqli_prepare($conn,"SELECT * FROM products WHERE id=?");mysqli_stmt_bind_param($s,'i',$id);mysqli_stmt_execute($s);$found=mysqli_fetch_assoc(mysqli_stmt_get_result($s));if($found)$p=$found;else exit('Product not found.');}
if($_SERVER['REQUEST_METHOD']==='POST'){
 $name=trim($_POST['name']??'');$desc=trim($_POST['description']??'');$category=$_POST['category']??'coffee';$price=(int)($_POST['price']??0);$active=isset($_POST['is_active'])?1:0;$image=$p['image'];
 if($name===''||$price<0||!in_array($category,['coffee','food','non_caffeine','other'],true))$error='Please check the product details.';
 if(!$error&&isset($_FILES['image'])&&$_FILES['image']['error']!==UPLOAD_ERR_NO_FILE){
  if($_FILES['image']['error']!==UPLOAD_ERR_OK||$_FILES['image']['size']>3*1024*1024)$error='Image upload failed or exceeds 3 MB.';
  else{$mime=(new finfo(FILEINFO_MIME_TYPE))->file($_FILES['image']['tmp_name']);$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;if(!$ext)$error='Only JPG, PNG or WEBP images are allowed.';else{$image=bin2hex(random_bytes(12)).'.'.$ext;move_uploaded_file($_FILES['image']['tmp_name'],__DIR__.'/../../uploads/product_images/'.$image);}}
 }
 if(!$error){
  if($id){$s=mysqli_prepare($conn,"UPDATE products SET name=?,description=?,category=?,price=?,image=?,is_active=? WHERE id=?");mysqli_stmt_bind_param($s,'sssisii',$name,$desc,$category,$price,$image,$active,$id);}
  else{$s=mysqli_prepare($conn,"INSERT INTO products(name,description,category,price,image,is_active) VALUES(?,?,?,?,?,?)");mysqli_stmt_bind_param($s,'sssisi',$name,$desc,$category,$price,$image,$active);}
  mysqli_stmt_execute($s);flash('Product saved.');header('Location: index.php');exit;
 }
 $p=array_merge($p,['name'=>$name,'description'=>$desc,'category'=>$category,'price'=>$price,'image'=>$image]);
}
page_header($id?'Edit Product':'Add Product','../../');
?>
<h2 class="section-title mb-3"><?= $id?'Edit':'Add' ?> Product</h2><div class="card shadow-sm"><div class="card-body"><div class="col-lg-7"><?php if($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data"><label class="form-label">Product name</label><input class="form-control mb-3" name="name" maxlength="100" value="<?= e($p['name']) ?>" required><label class="form-label">Description</label><textarea class="form-control mb-3" name="description" maxlength="255"><?= e($p['description']) ?></textarea><label class="form-label">Category</label><select class="form-select mb-3" name="category"><?php foreach(['coffee','food','non_caffeine','other'] as $c): ?><option value="<?= $c ?>" <?= $p['category']===$c?'selected':'' ?>><?= e(ucwords(str_replace('_',' ',$c))) ?></option><?php endforeach; ?></select><label class="form-label">Price (Rupiah)</label><input class="form-control mb-3" type="number" min="0" name="price" value="<?= e($p['price']) ?>" required><label class="form-label">Product image (JPG/PNG/WEBP, max 3 MB)</label><input class="form-control mb-3" type="file" name="image" accept=".jpg,.jpeg,.png,.webp"><?php if($p['image']): ?><p class="small text-muted">Current image: <?= e($p['image']) ?></p><?php endif; ?><div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="is_active" id="active" <?= $p['is_active']?'checked':'' ?>><label class="form-check-label" for="active">Visible on customer menu</label></div><button class="btn btn-dark">Save Product</button> <a class="btn btn-outline-secondary" href="index.php">Cancel</a></form></div></div></div>
<?php include __DIR__.'/../../footer.php'; ?>
