<?php
require_once __DIR__.'/../../functions.php';require_owner();
$id=(int)($_GET['id']??0);$s=mysqli_prepare($conn,"UPDATE products SET is_active=0 WHERE id=?");mysqli_stmt_bind_param($s,'i',$id);mysqli_stmt_execute($s);header('Location: index.php?deleted=1');exit;
