<?php
require_once __DIR__.'/../../functions.php';require_owner();
if(isset($_GET['deleted']))flash('Product removed from the menu.');
$rows=mysqli_query($conn,"SELECT * FROM products ORDER BY is_active DESC,name");page_header('Products','../../');
?>
<div class="d-flex justify-content-between align-items-center mb-3"><h2 class="section-title">Products</h2><a class="btn btn-dark" href="form.php">+ Add Product</a></div>
<div class="card shadow-sm"><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Status</th><th></th></tr></thead><tbody>
<?php while($p=mysqli_fetch_assoc($rows)): ?><tr><td><?= e($p['name']) ?></td><td><?= e($p['category']) ?></td><td><?= rupiah($p['price']) ?></td><td><?= $p['is_active']?'Active':'Hidden' ?></td><td class="text-end"><a class="btn btn-sm btn-outline-dark" href="form.php?id=<?= (int)$p['id'] ?>">Edit</a> <a class="btn btn-sm btn-outline-danger" onclick="return confirm('Remove this product?')" href="delete.php?id=<?= (int)$p['id'] ?>">Remove</a></td></tr><?php endwhile; ?>
</tbody></table></div></div>
<?php include __DIR__.'/../../footer.php'; ?>
