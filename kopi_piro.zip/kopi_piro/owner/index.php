<?php
require_once __DIR__.'/../functions.php';require_owner();
$products=(int)mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) n FROM products WHERE is_active=1"))['n'];
$orders=(int)mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) n FROM orders"))['n'];
$sales=(int)mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(total),0) n FROM orders WHERE status<>'cancelled'"))['n'];
$pending=(int)mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) n FROM orders WHERE status IN('pending','processing')"))['n'];
page_header('Owner Dashboard','../');
?>
<h2 class="section-title mb-4">Owner Dashboard</h2><div class="row g-3 mb-4">
<?php foreach([['Active Products',$products],['All Orders',$orders],['Total Sales',rupiah($sales)],['Open Orders',$pending]] as [$label,$value]): ?><div class="col-6 col-lg-3"><div class="stat-card"><div class="text-muted small"><?= e($label) ?></div><div class="fs-4 fw-bold"><?= e($value) ?></div></div></div><?php endforeach; ?>
</div>
<div class="row g-3"><div class="col-md-6"><div class="card shadow-sm"><div class="card-body"><h5>Product Management</h5><p class="text-muted">Add products, edit prices and upload product photos.</p><a class="btn btn-dark" href="products/index.php">Manage Products</a></div></div></div><div class="col-md-6"><div class="card shadow-sm"><div class="card-body"><h5>Sales & Orders</h5><p class="text-muted">View every order, assign cashiers and review sales reports.</p><a class="btn btn-dark" href="orders/index.php">Manage Orders</a> <a class="btn btn-outline-dark" href="reports/index.php">View Reports</a></div></div></div></div>
<?php include __DIR__.'/../footer.php'; ?>
