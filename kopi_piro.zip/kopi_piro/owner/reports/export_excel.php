<?php
require_once __DIR__.'/../../functions.php';require_owner();
header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="kopi_piro_sales_report.csv"');
$out=fopen('php://output','w');fputcsv($out,['Order ID','Date','Customer','Cashier','Status','Subtotal','Discount','Total']);
$q=mysqli_query($conn,"SELECT o.id,o.created_at,o.customer_name,u.name cashier,o.status,o.subtotal,o.discount,o.total FROM orders o LEFT JOIN users u ON u.id=o.cashier_id ORDER BY o.id DESC");
while($r=mysqli_fetch_assoc($q))fputcsv($out,$r);fclose($out);exit;
